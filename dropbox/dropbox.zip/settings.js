"use strict"

module.exports = {
  DROPBOX_TOKEN: 'vQ93mSgCFfIAAAAAAABOackceeKTK-sxWeXDpLBIaRuREBvSpYL2-82kiJAZfenY'
}
